# How to use :

Toggle "a" on your keyboard to see hardwired house
Toggle "s" on your keyboard to see triangle
Press "w" on your keyboard to draw a house

Press "e" on your keyboard to Exit the program
