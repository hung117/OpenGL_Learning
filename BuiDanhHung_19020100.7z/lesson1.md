# Create Window & draw triangle

The process transforming all 3D coordinates to 2D pixels that fit on your screen called <strong>graphics pipeline </strong><br/>
<br/>

-   include 2 parts:<br/>
    &nbsp;+transforms your 3D coordinates into 2D coordinates<br/>
    &nbsp;+transforms the 2D coordinates into actual colored pixels<br/>
